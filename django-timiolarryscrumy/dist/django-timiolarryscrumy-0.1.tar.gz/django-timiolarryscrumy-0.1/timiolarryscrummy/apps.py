from django.apps import AppConfig


class TimiolarryscrumyConfig(AppConfig):
    name = 'timiolarryscrumy'
